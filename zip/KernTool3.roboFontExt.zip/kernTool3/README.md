# KernTool3
 a set of extensions for working with kerning in RoboFont3
 
![](img/kerntool1@2x.jpg)
![](img/kerntool2@2x.jpg)
![](img/kerntool3@2x.jpg)
![](img/kerntool4@2x.jpg)
![](img/kerntool5@2x.jpg)
![](img/kerntool6@2x.jpg)
![](img/kerntool7@2x.jpg)
![](img/kerntool8@2x.jpg)
![](img/kerntool9@2x.jpg)
![](img/kerntool10@2x.jpg)
![](img/kerntool11@2x.jpg)
![](img/kerntool12@2x.jpg)
![](img/kerntool13@2x.jpg)
![](img/kerntool14@2x.jpg)
![](img/kerntool15@2x.jpg)



